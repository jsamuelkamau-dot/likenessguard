"""
Supervisor Lambda — Multi-Agent Orchestration Entry Point

The single API Gateway entry point for v2 consent checks.
Orchestrates the full 9-step pipeline:
  1. Input validation
  2. Image processing (Rekognition + Titan embeddings)
  3. OpenSearch k-NN matching
  4. Anomaly Agent screening
  5. Consent Orchestrator decision
  6. KMS Proof-of-Face signing (on ALLOW)
  7. Audit log write
  8. Discovery hint emission (if applicable)
  9. Response assembly with full reasoning trace

Target: <300ms P95 end-to-end

Requirements: 2.1, 2.2, 2.3, 2.7, 2.8, 2.9, 2.10, 10.1
"""
import base64
import hashlib
import json
import logging
import os
import time
import uuid
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))

CONSENT_REGISTRY_TABLE = os.environ.get('CONSENT_REGISTRY_TABLE', 'LikenessGuard-ConsentRegistry')
AUDIT_LOG_TABLE = os.environ.get('AUDIT_LOG_TABLE', 'LikenessGuard-AuditLog')
SUSPENSION_TABLE = os.environ.get('SUSPENSION_TABLE', 'LikenessGuard-Suspensions')
SIMILARITY_THRESHOLD = float(os.environ.get('SIMILARITY_THRESHOLD', '0.85'))
DISCOVERY_HINT_THRESHOLD = 0.70
USE_OPENSEARCH = os.environ.get('USE_OPENSEARCH', 'true').lower() == 'true'
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')

# Lambda function names for agent invocation
ANOMALY_AGENT_FN = os.environ.get('ANOMALY_AGENT_FN', 'LikenessGuard-AnomalyAgent')
ORCHESTRATOR_FN = os.environ.get('ORCHESTRATOR_FN', 'LikenessGuard-ConsentOrchestrator')
POLICY_REASONER_FN = os.environ.get('POLICY_REASONER_FN', 'LikenessGuard-PolicyReasoner')


def lambda_handler(event, context):
    """
    Supervisor entry point — handles POST /v2/consent/check

    Request body:
    {
        "image": str (base64),
        "usage_type": str,
        "requester_id": str,
        "platform": str (optional)
    }
    """
    pipeline_start = int(time.time() * 1000)
    request_id = str(uuid.uuid4())
    trace = {"request_id": request_id, "steps": {}}

    try:
        body = _parse_body(event)
        image_b64 = body.get('image', '')
        usage_type = body.get('usage_type', 'GENERAL_GENERATION')
        requester_id = body.get('requester_id', 'unknown')
        platform = body.get('platform', 'other')

        if not image_b64:
            return _api_response(400, {"error": "image field is required"})

        # Decode image
        try:
            image_bytes = base64.b64decode(image_b64)
        except Exception:
            return _api_response(400, {"error": "Invalid base64 image encoding"})

        # Validate image size
        if len(image_bytes) > 10 * 1024 * 1024:
            return _api_response(400, {"error": "Image exceeds 10MB limit"})

        reference_image_hash = 'sha256:' + hashlib.sha256(image_bytes).hexdigest()

        # ── Step 1: Generate Titan embedding ──────────────────────────────
        step_start = int(time.time() * 1000)
        try:
            from lambdas.shared.titan_embeddings import generate_facial_vector, FaceNotDetectedError
            query_vector = generate_facial_vector(image_bytes)
            rekognition_confidence = 99.0  # Rekognition validated face inside titan module
        except FaceNotDetectedError:
            return _api_response(200, {
                "request_id": request_id,
                "decision": "DENY",
                "reason_code": "FACE_NOT_DETECTED",
                "confidence": 1.0,
                "reasoning_trace": "No face detected in the reference image.",
                "proof_of_face": None,
                "agent_trace": trace
            })
        except Exception as e:
            logger.error(f"Embedding generation failed: {e}")
            return _api_response(200, {
                "request_id": request_id,
                "decision": "DENY",
                "reason_code": "EMBEDDING_ERROR",
                "confidence": 1.0,
                "reasoning_trace": "Failed to generate facial embedding.",
                "proof_of_face": None,
                "agent_trace": trace
            })
        trace['steps']['embedding_ms'] = int(time.time() * 1000) - step_start

        # ── Step 2: OpenSearch k-NN matching ──────────────────────────────
        step_start = int(time.time() * 1000)
        top_candidates = []
        best_match = None
        best_score = 0.0

        if USE_OPENSEARCH:
            try:
                from lambdas.shared.opensearch_client import knn_query
                top_candidates = knn_query(query_vector, k=10)
                if top_candidates:
                    best_match = top_candidates[0]
                    best_score = best_match.get('score', 0.0)
            except Exception as e:
                logger.warning(f"OpenSearch query failed, falling back to DynamoDB: {e}")
                best_match, best_score = _dynamodb_fallback_match(query_vector)
        else:
            best_match, best_score = _dynamodb_fallback_match(query_vector)

        trace['steps']['matching_ms'] = int(time.time() * 1000) - step_start
        trace['steps']['best_score'] = best_score
        trace['steps']['candidates_found'] = len(top_candidates)

        # ── Step 3: Discovery hint (unregistered subject) ─────────────────
        if best_score >= DISCOVERY_HINT_THRESHOLD and (not best_match or best_score < SIMILARITY_THRESHOLD):
            _emit_discovery_hint(reference_image_hash, best_score, request_id)

        # ── Step 4: Anomaly Agent screening ───────────────────────────────
        step_start = int(time.time() * 1000)
        request_count_1h, anomaly_count_1h = _get_requester_counts(requester_id)

        anomaly_result = _invoke_lambda(ANOMALY_AGENT_FN, {
            "requester_id": requester_id,
            "usage_type": usage_type,
            "request_payload_hash": reference_image_hash,
            "image_metadata": {"size_bytes": len(image_bytes), "hash": reference_image_hash},
            "request_count_1h": request_count_1h,
            "anomaly_count_1h": anomaly_count_1h
        })
        trace['steps']['anomaly_agent'] = anomaly_result
        trace['steps']['anomaly_ms'] = int(time.time() * 1000) - step_start

        if not anomaly_result.get('cleared', False):
            _write_audit_log(request_id, None, requester_id, 'DENY', 'ANOMALY_DETECTED',
                             best_score, 1, None, reference_image_hash, anomaly_result, None)
            return _api_response(200, {
                "request_id": request_id,
                "decision": "DENY",
                "reason_code": "ANOMALY_DETECTED",
                "threat_type": anomaly_result.get('threat_type'),
                "confidence": anomaly_result.get('confidence', 1.0),
                "reasoning_trace": anomaly_result.get('reasoning', ''),
                "proof_of_face": None,
                "agent_trace": trace
            })

        # ── Step 5: Load subject policy ───────────────────────────────────
        subject_id = best_match.get('subject_id') if best_match else None
        policy = {}
        policy_version = 1
        is_provisional = best_match.get('is_provisional', False) if best_match else False

        if subject_id:
            policy, policy_version = _load_policy(subject_id)

        # ── Step 6: Consent Orchestrator decision ─────────────────────────
        step_start = int(time.time() * 1000)
        orchestrator_result = _invoke_lambda(ORCHESTRATOR_FN, {
            "subject_id": subject_id or 'UNKNOWN',
            "policy": policy,
            "similarity_score": best_score,
            "usage_type": usage_type,
            "requester_id": requester_id,
            "anomaly_cleared": True,
            "top_candidates": top_candidates[:3],
            "policy_version": policy_version,
            "is_provisional": is_provisional
        })
        trace['steps']['orchestrator'] = orchestrator_result
        trace['steps']['orchestrator_ms'] = int(time.time() * 1000) - step_start

        decision = orchestrator_result.get('decision', 'DENY')
        reason_code = orchestrator_result.get('reason_code', 'UNKNOWN')
        confidence = orchestrator_result.get('confidence', 0.0)
        reasoning_trace = orchestrator_result.get('reasoning_trace', '')

        # ── Step 7: Proof-of-Face signing (ALLOW only) ────────────────────
        proof_of_face = None
        manifest_hash = None

        if decision == 'ALLOW' and subject_id:
            step_start = int(time.time() * 1000)
            try:
                from lambdas.shared.kms_signing import build_manifest, sign_manifest, get_manifest_hash, SigningError
                manifest = build_manifest(
                    subject_id=subject_id,
                    requester_id=requester_id,
                    decision=decision,
                    reason_code=reason_code,
                    similarity_score=best_score,
                    usage_type=usage_type,
                    agent_confidence=confidence,
                    reference_image_hash=reference_image_hash,
                    rekognition_confidence=rekognition_confidence,
                    policy_version=policy_version,
                    audit_id=request_id,
                    platform=platform
                )
                signed = sign_manifest(manifest)
                proof_of_face = signed
                manifest_hash = get_manifest_hash(signed)
                trace['steps']['signing_ms'] = int(time.time() * 1000) - step_start
            except SigningError as e:
                # Per Requirement 3.5: signing failure → DENY, never unsigned ALLOW
                logger.error(f"KMS signing failed: {e}")
                decision = 'DENY'
                reason_code = 'SIGNING_FAILURE'
                reasoning_trace = f'KMS signing failed. Defaulting to DENY for safety. Error: {e}'
                proof_of_face = None

        # ── Step 8: Audit log ─────────────────────────────────────────────
        _write_audit_log(
            request_id, subject_id, requester_id, decision, reason_code,
            best_score, policy_version, manifest_hash, reference_image_hash,
            anomaly_result, orchestrator_result
        )

        # ── Step 9: Response ──────────────────────────────────────────────
        total_ms = int(time.time() * 1000) - pipeline_start
        trace['total_latency_ms'] = total_ms

        return _api_response(200, {
            "request_id": request_id,
            "decision": decision,
            "reason_code": reason_code,
            "confidence": confidence,
            "similarity_score": best_score,
            "subject_id": subject_id,
            "reasoning_trace": reasoning_trace,
            "proof_of_face": proof_of_face,
            "agent_trace": trace,
            "latency_ms": total_ms
        })

    except Exception as e:
        logger.error(f"Supervisor unhandled error: {e}", exc_info=True)
        return _api_response(500, {"error": "Internal server error", "request_id": request_id})


def _invoke_lambda(function_name: str, payload: dict) -> dict:
    """Invoke a Lambda function synchronously."""
    try:
        client = boto3.client('lambda', region_name=AWS_REGION)
        response = client.invoke(
            FunctionName=function_name,
            InvocationType='RequestResponse',
            Payload=json.dumps(payload).encode('utf-8')
        )
        result = json.loads(response['Payload'].read())
        if response.get('FunctionError'):
            logger.error(f"Lambda {function_name} error: {result}")
            return {"cleared": True, "decision": "DENY", "reason_code": "AGENT_ERROR"}
        return result
    except Exception as e:
        logger.error(f"Failed to invoke {function_name}: {e}")
        return {"cleared": True, "decision": "DENY", "reason_code": "AGENT_UNAVAILABLE"}


def _load_policy(subject_id: str) -> tuple[dict, int]:
    """Load consent policy from DynamoDB."""
    try:
        ddb = boto3.client('dynamodb', region_name=AWS_REGION)
        response = ddb.get_item(
            TableName=CONSENT_REGISTRY_TABLE,
            Key={'LikenessID': {'S': subject_id}}
        )
        item = response.get('Item', {})
        policy_str = item.get('ConsentPolicy', {}).get('S', '{}')
        policy = json.loads(policy_str)
        version = int(item.get('PolicyVersion', {}).get('N', '1'))
        return policy, version
    except Exception as e:
        logger.error(f"Failed to load policy for {subject_id}: {e}")
        return {}, 1


def _dynamodb_fallback_match(query_vector: list) -> tuple[dict | None, float]:
    """Fallback: use DynamoDB fingerprint scan when OpenSearch unavailable."""
    # Returns (None, 0.0) — DynamoDB doesn't support vector search natively
    # The feature flag USE_OPENSEARCH should be true in production
    logger.warning("Using DynamoDB fallback — no vector similarity available")
    return None, 0.0


def _get_requester_counts(requester_id: str) -> tuple[int, int]:
    """Get request and anomaly counts for rate limiting."""
    # Simplified — in production use ElastiCache or DynamoDB counters
    return 0, 0


def _emit_discovery_hint(image_hash: str, score: float, request_id: str) -> None:
    """Emit a discovery hint for potential unregistered subject."""
    try:
        cw = boto3.client('cloudwatch', region_name=AWS_REGION)
        cw.put_metric_data(
            Namespace='LikenessGuard',
            MetricData=[{
                'MetricName': 'DiscoveryHintsEmitted',
                'Value': 1,
                'Unit': 'Count',
                'Dimensions': [{'Name': 'Environment', 'Value': 'production'}]
            }]
        )
        logger.info(f"Discovery hint emitted: score={score:.3f}, hash={image_hash[:16]}")
    except Exception as e:
        logger.warning(f"Failed to emit discovery hint metric: {e}")


def _write_audit_log(request_id, subject_id, requester_id, decision, reason_code,
                      similarity_score, policy_version, manifest_hash,
                      reference_image_hash, anomaly_result, orchestrator_result) -> None:
    """Write immutable audit log entry to DynamoDB."""
    try:
        import hashlib as hl
        timestamp = int(time.time())
        ttl = timestamp + (7 * 365 * 24 * 3600)  # 7 years

        entry = {
            "QueryID": {"S": request_id},
            "Timestamp": {"N": str(timestamp)},
            "LikenessID": {"S": subject_id or 'UNKNOWN'},
            "RequesterID": {"S": requester_id},
            "Decision": {"S": decision},
            "ReasonCode": {"S": reason_code},
            "SimilarityScore": {"N": str(round(similarity_score, 4))},
            "PolicyVersion": {"N": str(policy_version)},
            "ReferenceImageHash": {"S": reference_image_hash},
            "AnomalyCleared": {"BOOL": anomaly_result.get('cleared', True) if anomaly_result else True},
            "TTL": {"N": str(ttl)}
        }

        if manifest_hash:
            entry["ManifestHash"] = {"S": manifest_hash}

        if orchestrator_result:
            trace_str = json.dumps({
                "decision": orchestrator_result.get('decision'),
                "reason_code": orchestrator_result.get('reason_code'),
                "confidence": orchestrator_result.get('confidence')
            })
            entry["AgentTraceHash"] = {"S": 'sha256:' + hl.sha256(trace_str.encode()).hexdigest()}

        # Compute entry hash for tamper detection
        entry_content = json.dumps({k: list(v.values())[0] for k, v in entry.items()}, sort_keys=True)
        entry["EntryHash"] = {"S": 'sha256:' + hl.sha256(entry_content.encode()).hexdigest()}

        ddb = boto3.client('dynamodb', region_name=AWS_REGION)
        ddb.put_item(TableName=AUDIT_LOG_TABLE, Item=entry)

        # Emit CloudWatch metrics
        _emit_decision_metric(decision)

    except Exception as e:
        logger.error(f"Failed to write audit log: {e}")


def _emit_decision_metric(decision: str) -> None:
    try:
        cw = boto3.client('cloudwatch', region_name=AWS_REGION)
        cw.put_metric_data(
            Namespace='LikenessGuard',
            MetricData=[{
                'MetricName': f'ConsentDecision_{decision}',
                'Value': 1,
                'Unit': 'Count'
            }]
        )
    except Exception:
        pass


def _parse_body(event: dict) -> dict:
    body = event.get('body', event)
    if isinstance(body, str):
        return json.loads(body)
    return body or {}


def _api_response(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization"
        },
        "body": json.dumps(body)
    }
