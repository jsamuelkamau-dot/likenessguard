﻿"""
Policy Reasoner Agent Lambda - Nova Lite NL to JSON policy conversion
"""
import json, logging, os, time, boto3

logger = logging.getLogger()
logger.setLevel(os.environ.get("LOG_LEVEL", "INFO"))
BEDROCK_REGION = os.environ.get("BEDROCK_REGION", "us-east-1")
NOVA_LITE_MODEL = "amazon.nova-lite-v1:0"

DEFAULT_POLICY = {"allow_self_edits": True, "deny_third_party_edits": True, "deny_face_swaps": True,
    "deny_sexualized_content": True, "deny_impersonation": True, "deny_political_use": True,
    "platform_allowlist": [], "platform_blocklist": [], "commercial_use_allowed": False,
    "geographic_restrictions": [], "age_rating_max": "PG", "time_restrictions": None, "policy_version": 1}

NL_TO_JSON_PROMPT = """Convert this natural language consent statement to a JSON policy object.
Include ALL fields: allow_self_edits, deny_third_party_edits, deny_face_swaps, deny_sexualized_content,
deny_impersonation, deny_political_use, platform_allowlist (list), platform_blocklist (list),
commercial_use_allowed, geographic_restrictions (list), age_rating_max (G/PG/PG-13/R), time_restrictions (null).
Input: {input}
Respond with ONLY valid JSON."""

JSON_TO_NL_PROMPT = """Explain this consent policy in 2-3 plain English sentences. Start with what IS allowed.
Policy: {input}
Plain English only."""


def lambda_handler(event, context):
    start_ms = int(time.time() * 1000)
    mode = event.get("mode", "nl_to_json")
    input_text = event.get("input", "")
    existing_policy = event.get("existing_policy")
    if not input_text:
        return {"policy": None, "summary": "Input text is required", "conflicts": [], "resolution": "", "latency_ms": 0}
    try:
        if mode == "nl_to_json":
            return _nl_to_json(input_text, start_ms)
        elif mode == "json_to_nl":
            return _json_to_nl(input_text, start_ms)
        elif mode == "conflict_check":
            return _conflict_check(input_text, existing_policy, start_ms)
        else:
            return {"policy": None, "summary": f"Unknown mode: {mode}", "conflicts": [], "resolution": "", "latency_ms": 0}
    except Exception as e:
        logger.error(f"Policy Reasoner error: {e}")
        return {"policy": None, "summary": f"Error: {e}", "conflicts": [], "resolution": "", "latency_ms": int(time.time()*1000)-start_ms}


def _nl_to_json(input_text, start_ms):
    prompt = NL_TO_JSON_PROMPT.format(input=input_text)
    raw = _invoke_nova(prompt)
    try:
        clean = raw.strip()
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"): clean = clean[4:]
        policy = json.loads(clean.strip())
        merged = {**DEFAULT_POLICY, **policy}
        merged["policy_version"] = 1
        summary = _invoke_nova(JSON_TO_NL_PROMPT.format(input=json.dumps(merged)))
        return {"policy": merged, "summary": summary.strip(), "conflicts": [], "resolution": "", "latency_ms": int(time.time()*1000)-start_ms}
    except json.JSONDecodeError as e:
        return {"policy": None, "summary": f"Failed to parse policy: {e}", "conflicts": [], "resolution": "", "latency_ms": int(time.time()*1000)-start_ms}


def _json_to_nl(input_text, start_ms):
    summary = _invoke_nova(JSON_TO_NL_PROMPT.format(input=input_text))
    return {"policy": None, "summary": summary.strip(), "conflicts": [], "resolution": "", "latency_ms": int(time.time()*1000)-start_ms}


def _conflict_check(new_input, existing_policy, start_ms):
    if not existing_policy:
        return _nl_to_json(new_input, start_ms)
    prompt = f"""Check for conflicts between this existing policy and new statement.
Existing: {json.dumps(existing_policy)}
New: {new_input}
Respond JSON: {{"has_conflicts": bool, "conflicts": [], "resolution": "", "merged_policy": {{}}}}"""
    raw = _invoke_nova(prompt)
    try:
        clean = raw.strip()
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"): clean = clean[4:]
        result = json.loads(clean.strip())
        return {"policy": result.get("merged_policy"), "summary": "Conflict check complete.",
                "conflicts": result.get("conflicts", []), "resolution": result.get("resolution", ""),
                "latency_ms": int(time.time()*1000)-start_ms}
    except Exception as e:
        return {"policy": None, "summary": f"Conflict check error: {e}", "conflicts": [], "resolution": "", "latency_ms": int(time.time()*1000)-start_ms}


def _invoke_nova(prompt):
    bedrock = boto3.client("bedrock-runtime", region_name=BEDROCK_REGION)
    response = bedrock.invoke_model(
        modelId=NOVA_LITE_MODEL,
        body=json.dumps({"messages": [{"role": "user", "content": [{"text": prompt}]}],
                         "inferenceConfig": {"maxTokens": 1024, "temperature": 0.1}}),
        contentType="application/json", accept="application/json"
    )
    result = json.loads(response["body"].read())
    return result["output"]["message"]["content"][0]["text"]