"""
Registration Lambda Handler
Processes user registration, generates likeness fingerprints, stores consent policies.

Requirements:
- 1.1: User registration and authentication
- 2.1: Photo upload validation (5-10 images)
- 2.3: Photo-Likeness association
- 3.1: Face detection in uploaded photos
- 3.4: Facial feature extraction
- 4.1: Non-reversible fingerprint generation
- 15.3: Delete photos after processing
"""
import json
import logging
import os
import sys
import time
import uuid
from typing import Dict, Any, List, Tuple, Optional

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import boto3
from botocore.exceptions import ClientError

from shared.models.data_models import (
    RegistrationRequest,
    RegistrationResponse,
    ConsentRecord,
    UserMetadata
)
from shared.services.rekognition_client import (
    RekognitionClient,
    NoFaceDetectedError,
    MultipleFacesDetectedError,
    RekognitionServiceError
)
from shared.services.fingerprint_generator import (
    generate_fingerprint,
    FingerprintError
)
from shared.services.dynamodb_client import DynamoDBClient

# Configure logging
logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))

# Import structured logging and metrics
from shared.utils.structured_logger import StructuredLogger
from shared.utils.cloudwatch_metrics import CloudWatchMetrics

# Initialize structured logger and metrics
structured_logger = StructuredLogger(logger, 'registration')
metrics = CloudWatchMetrics()

# Initialize AWS clients
s3_client = boto3.client('s3')
rekognition_client = RekognitionClient()
dynamodb_client = DynamoDBClient()

# Get S3 bucket name from environment
PHOTOS_BUCKET = os.environ.get('PHOTOS_BUCKET', 'likenessguard-photos')


def download_photo_from_s3(photo_key: str) -> bytes:
    """
    Download a photo from S3.
    
    Args:
        photo_key: S3 object key for the photo
        
    Returns:
        Raw image bytes
        
    Raises:
        ClientError: If photo cannot be downloaded
        
    Requirements: 3.1
    """
    logger.info(f"Downloading photo from S3: {photo_key}")
    
    try:
        response = s3_client.get_object(Bucket=PHOTOS_BUCKET, Key=photo_key)
        image_bytes = response['Body'].read()
        logger.info(f"Downloaded {len(image_bytes)} bytes from {photo_key}")
        return image_bytes
    except ClientError as e:
        logger.error(f"Failed to download photo {photo_key}: {e}")
        raise


def delete_photo_from_s3(photo_key: str) -> None:
    """
    Delete a photo from S3 after processing.
    
    Args:
        photo_key: S3 object key for the photo
        
    Requirements: 15.3
    """
    logger.info(f"Deleting photo from S3: {photo_key}")
    
    try:
        s3_client.delete_object(Bucket=PHOTOS_BUCKET, Key=photo_key)
        logger.info(f"Deleted photo: {photo_key}")
    except ClientError as e:
        logger.warning(f"Failed to delete photo {photo_key}: {e}")
        # Don't raise - deletion failure shouldn't block registration


def process_photo(photo_key: str) -> Tuple[str, List[float], str]:
    """
    Process a single photo: download, detect face, extract embedding, generate fingerprint.
    
    Args:
        photo_key: S3 object key for the photo
        
    Returns:
        Tuple of (photo_key, embedding, fingerprint)
        
    Raises:
        NoFaceDetectedError: If no face is detected
        MultipleFacesDetectedError: If multiple faces are detected
        RekognitionServiceError: If Rekognition service fails
        FingerprintError: If fingerprint generation fails
        
    Requirements: 3.1, 3.4, 4.1
    """
    logger.info(f"Processing photo: {photo_key}")
    
    # Download photo from S3
    image_bytes = download_photo_from_s3(photo_key)
    
    # Detect face using Rekognition
    face_detection = rekognition_client.detect_faces(image_bytes)
    logger.info(f"Face detected in {photo_key} with {face_detection.confidence:.2f}% confidence")
    
    # Extract face embedding
    embedding = rekognition_client.extract_embedding(face_detection, image_bytes)
    logger.info(f"Extracted {len(embedding)}-dimensional embedding from {photo_key}")
    
    # Generate fingerprint
    fingerprint = generate_fingerprint(embedding)
    logger.info(f"Generated fingerprint for {photo_key}: {fingerprint[:16]}...")
    
    return photo_key, embedding, fingerprint


def process_all_photos(photo_keys: List[str]) -> Tuple[List[Tuple[str, List[float]]], List[str], List[str]]:
    """
    Process all photos and collect results.
    
    Args:
        photo_keys: List of S3 object keys for photos
        
    Returns:
        Tuple of (fingerprint_data, processed_photos, errors)
        where fingerprint_data is a list of (fingerprint_hash, embedding) tuples
        
    Requirements: 3.1, 3.4, 4.1, 15.3
    """
    fingerprint_data = []  # List of (fingerprint_hash, embedding) tuples
    processed_photos = []
    errors = []
    
    for photo_key in photo_keys:
        try:
            # Process photo
            _, embedding, fingerprint = process_photo(photo_key)
            
            # Store results (fingerprint hash and embedding)
            fingerprint_data.append((fingerprint, embedding))
            processed_photos.append(photo_key)
            
            # Delete photo from S3 after successful processing
            delete_photo_from_s3(photo_key)
            
        except NoFaceDetectedError as e:
            error_msg = f"No face detected in {photo_key}: {str(e)}"
            logger.warning(error_msg)
            errors.append(error_msg)
            # Still delete the photo
            delete_photo_from_s3(photo_key)
            
        except MultipleFacesDetectedError as e:
            error_msg = f"Multiple faces detected in {photo_key}: {str(e)}"
            logger.warning(error_msg)
            errors.append(error_msg)
            # Still delete the photo
            delete_photo_from_s3(photo_key)
            
        except RekognitionServiceError as e:
            error_msg = f"Rekognition error processing {photo_key}: {str(e)}"
            logger.error(error_msg)
            errors.append(error_msg)
            # Don't delete photo on service error - might be transient
            
        except FingerprintError as e:
            error_msg = f"Fingerprint generation error for {photo_key}: {str(e)}"
            logger.error(error_msg)
            errors.append(error_msg)
            # Delete photo even on fingerprint error
            delete_photo_from_s3(photo_key)
            
        except Exception as e:
            error_msg = f"Unexpected error processing {photo_key}: {str(e)}"
            logger.error(error_msg, exc_info=True)
            errors.append(error_msg)
            # Delete photo on unexpected error
            delete_photo_from_s3(photo_key)
    
    return fingerprint_data, processed_photos, errors


def store_consent_record_in_db(
    user_id: str,
    email: Optional[str],
    fingerprint_data: List[Tuple[str, List[float]]],
    consent_policy: 'ConsentPolicy'
) -> str:
    """
    Store consent record in DynamoDB.
    
    Creates a ConsentRecord with:
    - Generated Likeness_ID (UUID)
    - Primary fingerprint (first successful fingerprint)
    - Primary embedding (first successful embedding)
    - Consent policy
    - User metadata
    - Timestamps
    
    Args:
        user_id: User identifier
        email: Optional user email
        fingerprint_data: List of (fingerprint_hash, embedding) tuples
        consent_policy: User's consent policy
        
    Returns:
        Generated Likeness_ID
        
    Raises:
        ClientError: If DynamoDB operation fails
        
    Requirements: 4.5, 5.2, 5.3, 5.4, 12.3
    """
    # Generate unique Likeness_ID
    likeness_id = str(uuid.uuid4())
    logger.info(f"Generated Likeness_ID: {likeness_id}")
    
    # Use the first fingerprint and embedding as the primary ones
    # In a production system, we might store all fingerprints or combine them
    primary_fingerprint, primary_embedding = fingerprint_data[0]
    logger.info(f"Using primary fingerprint: {primary_fingerprint[:16]}...")
    
    # Create user metadata
    user_metadata = UserMetadata(
        user_id=user_id,
        email=email,
        registration_source='api'
    )
    
    # Get current timestamp
    current_time = int(time.time())
    
    # Create consent record
    consent_record = ConsentRecord(
        likeness_id=likeness_id,
        fingerprint_hash=primary_fingerprint,
        fingerprint_embedding=primary_embedding,
        consent_policy=consent_policy,
        user_metadata=user_metadata,
        created_at=current_time,
        modified_at=current_time
    )
    
    # Store in DynamoDB
    logger.info(f"Storing consent record for Likeness_ID: {likeness_id}")
    dynamodb_client.store_consent_record(consent_record)
    logger.info(f"Successfully stored consent record for Likeness_ID: {likeness_id}")
    
    # Log registration event to CloudWatch
    logger.info(
        f"REGISTRATION_EVENT: user_id={user_id}, likeness_id={likeness_id}, "
        f"fingerprints_count={len(fingerprint_data)}, timestamp={current_time}"
    )
    
    return likeness_id


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for user registration.
    
    This handler processes user registration requests by:
    1. Parsing and validating the incoming request
    2. Validating photo count (5-10 images)
    3. Downloading photos from S3
    4. Validating photos exist and are accessible
    
    Args:
        event: API Gateway event containing registration request
        context: Lambda context object
        
    Returns:
        API Gateway response with registration result
        
    Requirements: 1.1, 2.1, 2.3
    """
    request_id = context.request_id if hasattr(context, 'request_id') else str(uuid.uuid4())
    start_time = time.time()
    
    try:
        logger.info("Registration request received")
        
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        logger.info(f"Request body: {json.dumps(body, default=str)}")
        
        # Parse and validate registration request
        try:
            registration_request = RegistrationRequest.from_dict(body)
        except ValueError as e:
            logger.warning(f"Invalid registration request: {e}")
            structured_logger.log_error(
                error_type='INVALID_REQUEST',
                error_message=str(e),
                context={'body': body},
                request_id=request_id
            )
            metrics.record_error('INVALID_REQUEST', 'registration')
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': {
                        'code': 'INVALID_REQUEST',
                        'message': str(e)
                    }
                })
            }
        
        # Validate photo count (5-10 images) - already done in RegistrationRequest.from_dict
        photo_count = len(registration_request.photo_keys)
        logger.info(f"Validating {photo_count} photos for user {registration_request.user_id}")
        
        # Validate that photos exist in S3
        validated_photos = []
        errors = []
        
        for photo_key in registration_request.photo_keys:
            try:
                # Check if photo exists in S3
                logger.debug(f"Checking S3 object: s3://{PHOTOS_BUCKET}/{photo_key}")
                s3_client.head_object(Bucket=PHOTOS_BUCKET, Key=photo_key)
                validated_photos.append(photo_key)
                logger.debug(f"Photo validated: {photo_key}")
            except ClientError as e:
                error_code = e.response.get('Error', {}).get('Code', '')
                if error_code == '404' or error_code == 'NoSuchKey':
                    error_msg = f"Photo not found in S3: {photo_key}"
                    logger.warning(error_msg)
                    errors.append(error_msg)
                else:
                    error_msg = f"Error accessing photo {photo_key}: {error_code}"
                    logger.error(error_msg)
                    errors.append(error_msg)
            except Exception as e:
                error_msg = f"Unexpected error validating photo {photo_key}: {str(e)}"
                logger.error(error_msg, exc_info=True)
                errors.append(error_msg)
        
        # Check if we have enough valid photos
        if len(validated_photos) < 5:
            logger.error(f"Insufficient valid photos: {len(validated_photos)}/5 minimum")
            structured_logger.log_error(
                error_type='INSUFFICIENT_PHOTOS',
                error_message=f'At least 5 valid photos required, found {len(validated_photos)}',
                context={'validated_photos': len(validated_photos), 'errors': errors},
                request_id=request_id
            )
            metrics.record_error('INSUFFICIENT_PHOTOS', 'registration')
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': {
                        'code': 'INSUFFICIENT_PHOTOS',
                        'message': f'At least 5 valid photos required, found {len(validated_photos)}',
                        'details': errors
                    }
                })
            }
        
        # Log successful validation
        logger.info(f"Successfully validated {len(validated_photos)} photos")
        
        # Process all photos: detect faces, extract embeddings, generate fingerprints
        logger.info("Starting photo processing pipeline")
        fingerprint_data, processed_photos, processing_errors = process_all_photos(validated_photos)
        
        # Combine validation and processing errors
        all_errors = errors + processing_errors
        
        # Check if we have at least one successfully processed photo
        if len(fingerprint_data) == 0:
            logger.error("No photos were successfully processed")
            structured_logger.log_error(
                error_type='NO_VALID_FACES',
                error_message='No valid faces detected in any photos',
                context={'errors': all_errors},
                request_id=request_id
            )
            metrics.record_error('NO_VALID_FACES', 'registration')
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': {
                        'code': 'NO_VALID_FACES',
                        'message': 'No valid faces detected in any photos',
                        'details': all_errors
                    }
                })
            }
        
        logger.info(f"Successfully processed {len(fingerprint_data)} photos with valid faces")
        
        # Store consent record in DynamoDB
        try:
            likeness_id = store_consent_record_in_db(
                user_id=registration_request.user_id,
                email=registration_request.email,
                fingerprint_data=fingerprint_data,
                consent_policy=registration_request.consent_policy
            )
            logger.info(f"Consent record stored successfully with Likeness_ID: {likeness_id}")
        except ClientError as e:
            logger.error(f"Failed to store consent record in DynamoDB: {e}")
            structured_logger.log_error(
                error_type='DATABASE_ERROR',
                error_message='Failed to store consent record',
                context={'error': str(e)},
                request_id=request_id
            )
            metrics.record_error('DYNAMODB_ERROR', 'registration')
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': {
                        'code': 'DATABASE_ERROR',
                        'message': 'Failed to store consent record',
                        'details': str(e) if os.environ.get('DEBUG') == 'true' else None
                    }
                })
            }
        except Exception as e:
            logger.error(f"Unexpected error storing consent record: {e}", exc_info=True)
            structured_logger.log_error(
                error_type='INTERNAL_ERROR',
                error_message='Failed to store consent record',
                context={'error': str(e)},
                request_id=request_id
            )
            metrics.record_error('INTERNAL_ERROR', 'registration')
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': {
                        'code': 'INTERNAL_ERROR',
                        'message': 'Failed to store consent record',
                        'details': str(e) if os.environ.get('DEBUG') == 'true' else None
                    }
                })
            }
        
        # Determine status based on errors
        if len(all_errors) > 0:
            status = 'PARTIAL_SUCCESS'
        else:
            status = 'SUCCESS'
        
        # Calculate processing time
        processing_time_ms = int((time.time() - start_time) * 1000)
        
        # Log structured registration event
        structured_logger.log_registration(
            user_id=registration_request.user_id,
            likeness_id=likeness_id,
            photos_processed=len(processed_photos),
            photos_total=len(registration_request.photo_keys),
            status=status,
            request_id=request_id,
            errors=all_errors if all_errors else None
        )
        
        # Record processing time metric
        metrics.record_processing_time('registration', processing_time_ms)
        
        response = RegistrationResponse(
            likeness_id=likeness_id,
            status=status,
            processed_photos=len(processed_photos),
            errors=all_errors if all_errors else None
        )
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(response.to_dict())
        }
        
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in request body: {e}")
        structured_logger.log_error(
            error_type='INVALID_JSON',
            error_message='Request body must be valid JSON',
            context={'error': str(e)},
            request_id=request_id
        )
        metrics.record_error('INVALID_JSON', 'registration')
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': {
                    'code': 'INVALID_JSON',
                    'message': 'Request body must be valid JSON'
                }
            })
        }
    except Exception as e:
        logger.error(f"Registration error: {str(e)}", exc_info=True)
        structured_logger.log_error(
            error_type='INTERNAL_ERROR',
            error_message='Registration failed',
            context={'error': str(e)},
            request_id=request_id
        )
        metrics.record_error('INTERNAL_ERROR', 'registration')
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': {
                    'code': 'INTERNAL_ERROR',
                    'message': 'Registration failed',
                    'details': str(e) if os.environ.get('DEBUG') == 'true' else None
                }
            })
        }
